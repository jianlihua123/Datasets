# Multi-focus-Image-Fusion-Dataset
New dataset

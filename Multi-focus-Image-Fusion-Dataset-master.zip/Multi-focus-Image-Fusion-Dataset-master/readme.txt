The dataset which includes 150 different images is created to use in Multi-focus Image Fusion algorithms. This dataset is different from other datasets in this area. The new dataset includes more than two images to fuse. And this propoerty is very important for this dataset.

The dataset is prepared by Samet Aymaz.